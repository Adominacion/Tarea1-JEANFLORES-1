import os
path, _ = os.path.split(os.path.abspath(__file__))
print("path=",path)
