 # def __str__(self):
    #     # Método especial para representar la clase Cliente como una cadena
    #     return f'Cliente: {self.first_name} {self.last_name}'  